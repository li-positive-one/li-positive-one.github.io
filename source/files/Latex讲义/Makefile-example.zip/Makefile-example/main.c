/*main.c*/
#include"mytool1.h"
#include"mytool2.h"
int main()
{
    mytool1_print("hello mytool1!");
    mytool2_print("hello mytool2!");
    return 0;
}
 

