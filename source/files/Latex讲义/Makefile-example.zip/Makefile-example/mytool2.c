/*mytool2.c*/
#include"mytool2.h"
#include<stdio.h>
void mytool2_print(char *print_str)
{
    printf("This is mytool2 print : %s ", print_str);
}
 

