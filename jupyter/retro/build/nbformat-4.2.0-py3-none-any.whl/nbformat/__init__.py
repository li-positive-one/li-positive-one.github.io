"""A nbformat mock"""

__version__ = "4.2.0"
